import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// --- 1. GLOBAL CONFIGURATION ---
class Config {
  static const String apiUrl = "http://192.168.1.40:8090/api/v1/";
  static const String db = "artisan_cafe";
  static const String brand = "FACTORY FEAST";
  static const String logoPath = 'assets/images/artisian.png';
}

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(primaryColor: const Color(0xFF0F2027), fontFamily: 'Roboto'),
    home: const FactorySplashScreen(),
  ));
}

// --- 2. INDUSTRIAL DESIGN SYSTEM ---
class AppColors {
  static const Color primaryNavy = Color(0xFF0F2027);
  static const Color industrialGray = Color(0xFF203A43);
  static const Color accentGold = Color(0xFFD4AF37);
  static const Color successGreen = Color(0xFF27AE60);
  static const Color errorRed = Color(0xFFE74C3C);
  static const Color scaffoldBg = Color(0xFFF4F7F9);
  static const Color textWhite = Colors.white;
  static const Color textHighContrast = Colors.black87;
}

// --- 3. DATA MODELS ---
class TaxRule {
  final String label;
  final double percentage;
  TaxRule({required this.label, required this.percentage});
  factory TaxRule.fromJson(Map<String, dynamic> j) =>
      TaxRule(label: j['label'] ?? 'TAX', percentage: (j['percentage'] ?? 0.0).toDouble());
}

class Category {
  final String code;
  final String name;
  Category({required this.code, required this.name});
  factory Category.fromJson(Map<String, dynamic> j) =>
      Category(code: j['categoryCode'] ?? '', name: j['categoryName'] ?? '');
}

class Modifier {
  final String code;
  final String name;
  final double price;
  Modifier({required this.code, required this.name, required this.price});
  factory Modifier.fromJson(Map<String, dynamic> j) =>
      Modifier(code: j['modifierCode'] ?? '0', name: j['modifierName'] ?? '', price: (j['price'] ?? 0.0).toDouble());
}

class Variant {
  final int id;
  final String name;
  final double price;
  Variant({required this.id, required this.name, required this.price});
  factory Variant.fromJson(Map<String, dynamic> j) =>
      Variant(id: j['variantId'] ?? 0, name: j['variantName'] ?? '', price: (j['additionalPrice'] ?? 0.0).toDouble());
}

class Product {
  final int sku;
  final String name;
  final String catCode;
  final double price;
  final String taxGroup;
  Product({required this.sku, required this.name, required this.catCode, required this.price, required this.taxGroup});
  factory Product.fromMap(Map<String, dynamic> j) => Product(
    sku: j['skuCode'] ?? 0,
    name: j['productName'] ?? j['product_display_name'] ?? 'ITEM',
    catCode: j['categoryCode'] ?? j['category_code'] ?? '',
    price: (j['baseFactoryPrice'] ?? j['base_factory_price'] ?? 0.0).toDouble(),
    taxGroup: j['taxIndicator'] ?? 'A',
  );
}

class CartItem {
  final Product product;
  Variant? variant;
  List<Modifier> modifiers;
  List<TaxRule> taxes;
  CartItem({required this.product, this.variant, required this.modifiers, required this.taxes});

  double get unitBasePrice => product.price + (variant?.price ?? 0.0) + modifiers.fold(0.0, (s, m) => s + m.price);
  double get totalTax => taxes.fold(0.0, (sum, t) => sum + (unitBasePrice * (t.percentage / 100)));
  double get totalWithTax => unitBasePrice + totalTax;
}

// --- 4. ANIMATED SPLASH SCREEN ---
class FactorySplashScreen extends StatefulWidget {
  const FactorySplashScreen({super.key});
  @override
  _FactorySplashScreenState createState() => _FactorySplashScreenState();
}

class _FactorySplashScreenState extends State<FactorySplashScreen> {
  double _logoY = 0.0;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) setState(() => _logoY = -0.6);
    });
    Future.delayed(const Duration(seconds: 4), () =>
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (c) => const FactoryLoginScreen())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryNavy,
      body: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(seconds: 2),
            curve: Curves.easeInOutBack,
            alignment: Alignment(0, _logoY),
            child: Image.asset(Config.logoPath, height: 240),
          ),
          const Align(alignment: Alignment(0, 0.6), child: CircularProgressIndicator(color: AppColors.accentGold))
        ],
      ),
    );
  }
}

// --- 5. MODERN LOGIN SCREEN ---
class FactoryLoginScreen extends StatefulWidget {
  const FactoryLoginScreen({super.key});
  @override
  _FactoryLoginScreenState createState() => _FactoryLoginScreenState();
}

class _FactoryLoginScreenState extends State<FactoryLoginScreen> {
  final user = TextEditingController();
  final pass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              colors: [AppColors.primaryNavy, AppColors.industrialGray],
              begin: Alignment.topCenter, end: Alignment.bottomCenter
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 450),
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.95),
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 25)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(Config.logoPath, height: 250, fit: BoxFit.contain),
                  const SizedBox(height: 5),
                  const Text(Config.brand, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 28, letterSpacing: 3, color: AppColors.primaryNavy)),
                  const Text("SECURE COMMAND TERMINAL", style: TextStyle(color: Colors.blueGrey, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 25),
                  TextField(controller: user, decoration: const InputDecoration(labelText: "ADMINISTRATOR ID", prefixIcon: Icon(Icons.person, color: AppColors.primaryNavy), border: OutlineInputBorder())),
                  const SizedBox(height: 15),
                  TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: "ACCESS KEY", prefixIcon: Icon(Icons.vpn_key, color: AppColors.primaryNavy), border: OutlineInputBorder())),
                  const SizedBox(height: 30),
                  SizedBox(
                      width: double.infinity, height: 55,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryNavy, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                          onPressed: () {
                            if (user.text == "admin" && pass.text == "123") {
                              Navigator.pushReplacement(context, MaterialPageRoute(builder: (c) => const FactoryPOSScreen()));
                            }
                          },
                          child: const Text("LOGIN", style: TextStyle(color: AppColors.accentGold, fontWeight: FontWeight.bold, letterSpacing: 1))
                      )
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// --- 6. COMMAND CENTER POS ---
class FactoryPOSScreen extends StatefulWidget {
  const FactoryPOSScreen({super.key});
  @override
  _FactoryPOSScreenState createState() => _FactoryPOSScreenState();
}

class _FactoryPOSScreenState extends State<FactoryPOSScreen> with SingleTickerProviderStateMixin {
  late TabController _tabs;
  bool isLoad = true;
  List<Product> prods = [];
  List<Category> cats = [];
  List<CartItem> cart = [];
  String selCat = "";

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _sync();
  }

  Future<void> _sync() async {
    final pR = await http.get(Uri.parse("${Config.apiUrl}products/getAll?DB=${Config.db}"));
    final cR = await http.get(Uri.parse("${Config.apiUrl}category/getAll?DB=${Config.db}"));
    if (pR.statusCode == 200) prods = (json.decode(pR.body) as List).map((e) => Product.fromMap(e)).toList();
    if (cR.statusCode == 200) cats = (json.decode(cR.body) as List).map((e) => Category.fromJson(e)).toList();
    if (cats.isNotEmpty) selCat = cats.first.code;
    setState(() => isLoad = false);
  }

  // --- CORE ORDER CREATE FUNCTION (SYNC TO FACTORY) ---
  Future<void> _pushOrder(String type, {List<Map<String, dynamic>>? mock}) async {
    final url = "${Config.apiUrl}factory/orders/create?DB=${Config.db}";

    // Get current date and time for the manifest
    String manifestDate = DateTime.now().toIso8601String().split('T')[0];
    String manifestTime = TimeOfDay.now().format(context);

    final body = jsonEncode({
      "manifestNo": "F-${DateTime.now().millisecondsSinceEpoch}",
      "fulfillmentType": type, // Ensure this matches DTO field name exactly
      "licenseKey": "LIC-FACTORY-FEAST-2026", // Required by backend
      "manifestDate": manifestDate,
      "manifestTime": manifestTime,
      "outletBrand": Config.brand,
      "workflowStatus": "PLACED",
      "chefInstructions": "Handle with care",
      "items": mock ?? cart.map((e) => {
        "productSku": e.product.sku.toString(),
        "itemDescription": e.product.name,
        "receiveQty": 1,
        "unitBasePrice": e.unitBasePrice,
        "grossLineTotal": e.totalWithTax,
      }).toList(),
    });

    try {
      final res = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: body,
      );

      if (res.statusCode == 201) {
        if (mock == null) setState(() => cart.clear());
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("MANIFEST CREATED SUCCESSFULLY"),
          backgroundColor: AppColors.successGreen,
        ));
      }
    } catch (e) {
      print("Error: $e");
    }
  }
  void _configure(Product p) async {
    final vR = await http.get(Uri.parse("${Config.apiUrl}variants/${p.sku}?DB=${Config.db}"));
    final mR = await http.get(Uri.parse("${Config.apiUrl}modifiers/getAll?DB=${Config.db}"));
    final tR = await http.get(Uri.parse("${Config.apiUrl}taxes/${p.taxGroup}?DB=${Config.db}"));

    List<Variant> vs = (vR.statusCode == 200) ? (json.decode(vR.body) as List).map((e) => Variant.fromJson(e)).toList() : [];
    List<Modifier> ms = (mR.statusCode == 200) ? (json.decode(mR.body) as List).map((e) => Modifier.fromJson(e)).toList() : [];
    List<TaxRule> ts = (tR.statusCode == 200) ? (json.decode(tR.body) as List).map((e) => TaxRule.fromJson(e)).toList() : [];

    Variant? sv; List<Modifier> sm = [];
    showDialog(context: context, builder: (c) => StatefulBuilder(builder: (c, st) => AlertDialog(
        insetPadding: const EdgeInsets.all(20), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Container(color: AppColors.primaryNavy, padding: const EdgeInsets.all(15), child: Text(p.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.accentGold, fontSize: 16))),
        content: SizedBox(width: MediaQuery.of(context).size.width * 0.7, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(padding: EdgeInsets.all(15), child: Text("SELECT VARIANT", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          ...vs.map((v) => RadioListTile<Variant>(activeColor: AppColors.primaryNavy, title: Text(v.name), value: v, groupValue: sv, onChanged: (x) => st(() => sv = x))),
          const Divider(),
          const Padding(padding: EdgeInsets.all(15), child: Text("SELECT MODIFIERS", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          ...ms.map((m) => CheckboxListTile(activeColor: AppColors.primaryNavy, title: Text(m.name), value: sm.contains(m), onChanged: (x) => st(() { if(x!) sm.add(m); else sm.remove(m); })))
        ]))),
        actions: [ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryNavy), onPressed: () { setState(() => cart.add(CartItem(product: p, variant: sv, modifiers: List.from(sm), taxes: ts))); Navigator.pop(c); }, child: const Text("COMMIT TO ORDER", style: TextStyle(color: AppColors.accentGold)))]
    )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.scaffoldBg,
      appBar: AppBar(backgroundColor: AppColors.primaryNavy, elevation: 0, centerTitle: true,
          title: const Text(Config.brand, style: TextStyle(color: AppColors.accentGold, letterSpacing: 4, fontWeight: FontWeight.w900, fontSize: 20)),
          bottom: TabBar(controller: _tabs, indicatorColor: AppColors.accentGold, tabs: const [
            Tab(child: Text("NEW SALE", style: TextStyle(color: AppColors.textWhite, fontWeight: FontWeight.bold, fontSize: 11))),
            Tab(child: Text("ADVANCE", style: TextStyle(color: AppColors.textWhite, fontWeight: FontWeight.bold, fontSize: 11))),
            Tab(child: Text("URGENT", style: TextStyle(color: AppColors.textWhite, fontWeight: FontWeight.bold, fontSize: 11))),
          ],)),
      body: isLoad ? const Center(child: CircularProgressIndicator()) : TabBarView(controller: _tabs, children: [_buildPos(), _buildQ("ADVANCE"), _buildQ("URGENT")]),
    );
  }

  Widget _buildPos() => Row(children: [
    Expanded(flex: 3, child: Column(children: [
      Container(height: 60, color: Colors.white, child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: cats.length, itemBuilder: (c, i) => Padding(padding: const EdgeInsets.all(8), child: ChoiceChip(label: Text(cats[i].name), selected: selCat == cats[i].code, onSelected: (v) => setState(() => selCat = cats[i].code))))),
      Expanded(child: GridView.builder(padding: const EdgeInsets.all(15), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 10, mainAxisSpacing: 10), itemCount: prods.where((p) => p.catCode == selCat).length, itemBuilder: (c, i) {
        final p = prods.where((x) => x.catCode == selCat).toList()[i];
        return InkWell(onTap: () => _configure(p), child: Container(decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.grey[200]!)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(p.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 10, color: AppColors.primaryNavy)), Text("₹${p.price}", style: const TextStyle(color: AppColors.successGreen, fontWeight: FontWeight.w900))])));
      }))
    ])),
    const VerticalDivider(width: 1),
    Expanded(flex: 2, child: _buildBillingSidebar())
  ]);

  Widget _buildBillingSidebar() {
    return Column(children: [
      Container(width: double.infinity, padding: const EdgeInsets.all(15), color: AppColors.industrialGray, child: const Text("ORDER AUDIT SUMMARY", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      Expanded(child: ListView.builder(
        itemCount: cart.length,
        itemBuilder: (c, i) {
          final item = cart[i];
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.grey[200]!)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  title: Text(item.product.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
                  trailing: Text("₹${item.product.price}", style: const TextStyle(fontWeight: FontWeight.w900)),
                  leading: IconButton(icon: const Icon(Icons.remove_circle, color: Colors.red, size: 20), onPressed: () => setState(() => cart.removeAt(i))),
                ),
                if (item.variant != null) Padding(padding: const EdgeInsets.only(left: 70), child: Text("+ ${item.variant!.name} (₹${item.variant!.price})", style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.blueGrey))),
                ...item.modifiers.map((m) => Padding(padding: const EdgeInsets.only(left: 70), child: Text("+ ${m.name} (₹${m.price})", style: const TextStyle(fontSize: 10, fontStyle: FontStyle.italic, color: Colors.blueGrey)))),
                const Divider(),
                Padding(padding: const EdgeInsets.all(10), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text("TAX & SURCHARGE", style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold)), Text("₹${item.totalTax.toStringAsFixed(2)}", style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold))])),
              ],
            ),
          );
        },
      )),
      Container(padding: const EdgeInsets.all(20), color: Colors.white, child: Column(children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text("GRAND TOTAL", style: TextStyle(fontWeight: FontWeight.w900)), Text("₹${cart.fold(0.0, (s, i) => s + i.totalWithTax).toStringAsFixed(2)}", style: const TextStyle(color: AppColors.errorRed, fontWeight: FontWeight.w900, fontSize: 24))]), const SizedBox(height: 15), SizedBox(width: double.infinity, height: 55, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryNavy), onPressed: () => _pushOrder("SALE"), child: const Text("CONFIRM & SAVE TRANSACTION", style: TextStyle(color: AppColors.accentGold, fontWeight: FontWeight.bold, fontSize: 10))))])),
    ]);
  }

  Widget _buildQ(String type) {
    final mockData = type == "URGENT" ? [
      {"id": "URG-401", "loc": "South Point Mall", "items": "15x Croissant", "amt": 2700.0, "time": "14:00"},
      {"id": "URG-402", "loc": "Railway Hub", "items": "20x Baguette", "amt": 3000.0, "time": "14:15"},
      {"id": "URG-403", "loc": "Airport Wing A", "items": "5x Choco Cake", "amt": 6000.0, "time": "14:30"},
      {"id": "URG-404", "loc": "Main City Cafe", "items": "10x Sourdough", "amt": 1800.0, "time": "14:45"},
      {"id": "URG-405", "loc": "Corporate Park", "items": "12x Pastry", "amt": 1440.0, "time": "15:00"},
    ] : [
      {"id": "ADV-701", "loc": "North Side Shop", "items": "25x Baguette", "amt": 3750.0, "time": "Jan 04"},
      {"id": "ADV-702", "loc": "East Coast Hub", "items": "10x Sourdough", "amt": 1800.0, "time": "Jan 04"},
      {"id": "ADV-703", "loc": "Green Valley", "items": "5x Wedding Cake", "amt": 15000.0, "time": "Jan 05"},
      {"id": "ADV-704", "loc": "High Street Cafe", "items": "50x Cookies", "amt": 4750.0, "time": "Jan 05"},
      {"id": "ADV-705", "loc": "River Side Hub", "items": "30x Croissant", "amt": 3600.0, "time": "Jan 06"},
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: mockData.length,
      itemBuilder: (c, i) => Card(
        shape: RoundedRectangleBorder(side: BorderSide(color: Colors.grey[300]!)),
        child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(mockData[i]['id'] as String, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: AppColors.textHighContrast)),
            Text(mockData[i]['loc'] as String, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
            Text(mockData[i]['items'] as String, style: const TextStyle(fontSize: 10, color: AppColors.textHighContrast, fontWeight: FontWeight.w900)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text("DUE: ${mockData[i]['time']}", style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: AppColors.errorRed)),
            Text("₹${(mockData[i]['amt'] as double).toStringAsFixed(2)}", style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: AppColors.textHighContrast)),
            SizedBox(height: 8),
            SizedBox(height: 35, child: ElevatedButton(
              onPressed: () => _pushOrder(type, mock: [{"productSku": "MOCK", "itemDescription": mockData[i]['items'] as String, "receiveQty": 1, "unitBasePrice": mockData[i]['amt'] as double, "grossLineTotal": mockData[i]['amt'] as double}]),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryNavy),
              child: const Text("PUSH TO KITCHEN", style: TextStyle(fontSize: 8, color: AppColors.accentGold, fontWeight: FontWeight.w900)),
            ))
          ])
        ])),
      ),
    );
  }
}