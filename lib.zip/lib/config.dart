import 'dart:convert';
import 'package:flutter/services.dart';

class Config {
  static Map<String, dynamic>? _config;

  static Future<void> load() async {
    final String configString = await rootBundle.loadString('assets/config.json');
    _config = json.decode(configString);
  }

  static String get apiUrl => _config?['apiUrl'] ?? '';
  static String get clientCode => _config?['CLIENTCODE'] ?? '';
  static String get weraApiUrl => _config?['weraApiUrl'] ?? '';
  static String get merchantId => _config?['merchantId'] ?? '';
  static String get weraApiKey => _config?['weraApiKey'] ?? '';

  // --- LOGO & TITLE CONFIG ---
  static String get logoPath => _config?['LOGO_PATH'] ?? 'assets/images/default.png';
  static String get posTitle => _config?['POS_TITLE'] ?? 'POS System';

  // --- FACTORY (SENDER) DETAILS ---
  static String get factoryName => _config?['FACTORY_DETAILS']['name'] ?? 'N/A';
  static String get factoryGstin => _config?['FACTORY_DETAILS']['gstin'] ?? 'N/A';
  static String get factoryAddress1 => _config?['FACTORY_DETAILS']['addressLine1'] ?? 'N/A';
  static String get factoryAddress2 => _config?['FACTORY_DETAILS']['addressLine2'] ?? 'N/A';
  static String get factoryPhone => _config?['FACTORY_DETAILS']['phone'] ?? 'N/A';
  static String get factoryFssaiCode => _config?['FACTORY_DETAILS']['fssaiCode'] ?? 'N/A';
  static String get factoryBankAccNo => _config?['FACTORY_DETAILS']['bankAccountNo'] ?? 'N/A';
  static String get factoryBankName => _config?['FACTORY_DETAILS']['name'] ?? 'N/A';
  static String get factoryBankBranch => _config?['FACTORY_DETAILS']['bankBranch'] ?? 'N/A';
  static String get factoryBankIfsc => _config?['FACTORY_DETAILS']['bankIfsc'] ?? 'N/A';
  static String get factoryJurisdiction => _config?['FACTORY_DETAILS']['jurisdiction'] ?? 'Mumbai';

  // --- CUSTOMER (RECEIVER/CONSIGNEE) DETAILS ---
  static String get customerName => _config?['CUSTOMER_DETAILS']['name'] ?? 'N/A';
  static String get customerAddress1 => _config?['CUSTOMER_DETAILS']['addressLine1'] ?? 'N/A';
  static String get customerStateCode => _config?['CUSTOMER_DETAILS']['stateCode'] ?? 'N/A';
  static String get customerFssaiCode => _config?['CUSTOMER_DETAILS']['fssaiCode'] ?? 'N/A';
  static String get customerGstin => _config?['CUSTOMER_DETAILS']['gstin'] ?? 'N/A';
  static String get customerContactNo => _config?['CUSTOMER_DETAILS']['contactNo'] ?? 'N/A';
}