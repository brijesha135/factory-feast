import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'config.dart';

class OrderService {
  static final OrderService _instance = OrderService._internal();
  factory OrderService() => _instance;
  OrderService._internal();

  final ValueNotifier<List<dynamic>> pendingOrders = ValueNotifier([]);
  final ValueNotifier<List<dynamic>> completedOrders = ValueNotifier([]);
  final ValueNotifier<bool> isLoading = ValueNotifier(true);

  Timer? _refreshTimer;
  final AudioPlayer _audioPlayer = AudioPlayer();
  final Set<String> _notifiedOrderIds = {};

  void startPolling() {
    _refreshTimer?.cancel();
    fetchOrders();
    _refreshTimer = Timer.periodic(Duration(seconds: 10), (timer) => _silentRefresh());
  }

  void stopPolling() {
    _refreshTimer?.cancel();
    _audioPlayer.stop();
    isLoading.value = true;
  }

  Future<void> fetchOrders() async {
    isLoading.value = true;
    try {
      final response = await http.get(Uri.parse('${Config.apiUrl}getAll?DB=${Config.clientCode}'));
      if (response.statusCode == 200) {
        final parsed = json.decode(response.body).cast<Map<String, dynamic>>();
        _processOrders(parsed, playSound: false);
      }
    } catch (e) {
      debugPrint('Fetch Error: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _silentRefresh() async {
    try {
      final response = await http.get(Uri.parse('${Config.apiUrl}getAll?DB=${Config.clientCode}'));
      if (response.statusCode == 200) {
        final parsed = json.decode(response.body).cast<Map<String, dynamic>>();
        _processOrders(parsed, playSound: true);
      }
    } catch (e) {
      debugPrint('Polling Error: $e');
    }
  }

  void _processOrders(List<dynamic> parsed, {bool playSound = false}) {
    // Logic: Map backend 'workflowStatus' to UI Tabs
    final newPending = parsed.where((o) =>
    o['workflowStatus'] != 'COMPLETED' && o['workflowStatus'] != 'CANCELLED'
    ).toList();

    final newCompleted = parsed.where((o) => o['workflowStatus'] == 'COMPLETED').toList();

    bool hasNewOrder = false;
    for (var order in newPending) {
      final id = order['manifestId'].toString();
      if (!_notifiedOrderIds.contains(id)) {
        hasNewOrder = true;
        _notifiedOrderIds.add(id);
      }
    }

    if (playSound && hasNewOrder) {
      _audioPlayer.stop();
      _audioPlayer.play(AssetSource('sounds/notification.mp3'));
    }

    pendingOrders.value = newPending;
    completedOrders.value = newCompleted;
  }
}